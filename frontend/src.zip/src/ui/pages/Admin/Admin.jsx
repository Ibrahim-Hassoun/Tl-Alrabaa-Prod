import React from 'react';
import AdminPanel from '../../layouts/Admin/AdminPanel';

const Admin = () => {
  return <AdminPanel />;
};

export default Admin;
