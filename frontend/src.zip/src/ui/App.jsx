
import Navbar from './layouts/Navbar/Navbar';
import './App.css'
import { BrowserRouter, Routes ,Route} from 'react-router-dom';
import Home from './pages/Home/Home';
import Cart from './pages/Cart/Cart';
import Register from './pages/Register/Register';
import Admin from './pages/Admin/Admin';
import AuthGuard from '../lib/middleware/AuthGuard';
function App() {
  

  return (
   <>
      <BrowserRouter>
      <Navbar></Navbar>
        <Routes>
          
          <AuthGuard>
            <Route path="/" element={<Home />} />
          </AuthGuard>
          
          <Route path="/cart" element={<Cart />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<Admin />} />
          
          
        </Routes>
          
      </BrowserRouter>
   </>
   
  )
}

export default App
